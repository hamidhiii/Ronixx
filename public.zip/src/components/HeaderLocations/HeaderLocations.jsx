import React from 'react'
import "./HeaderLocations.scss"
export default function HeaderLocations() {
  return (
    <div className='HeaderLocation'>
        
    </div>
  )
}
