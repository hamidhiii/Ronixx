import React, { useState } from "react";
import "./ProductCard.scss";
import { FaStar } from "react-icons/fa";
import { FaPlus, FaMinus } from "react-icons/fa";
import ProductAccardion from "../ProductAccardion/ProductAccardion";
import { useDispatch } from "react-redux";
import { addToCart } from "../../redux/cartSlice";

export default function ProductCard({ product }) {
  const dispatch = useDispatch();

  const {
    model,
    translations,
    barcode_color,
    barcode_carton,
    images,
    price
  } = product;

  const [activeAccordion, setActiveAccordion] = useState("0");

  const toggleAccordion = (key) => {
    setActiveAccordion(activeAccordion === key ? null : key);
  };

  // const handleBulkOrder = () => {
  //   dispatch(
  //     addToCart({
  //       id: product.id,
  //       name: translations.en.name,
  //       model,
  //       barcode: barcode_color,
  //       price,
  //     })
  //   );
  // };

  return (
    <div className="product-card">
      <div className="top-label">
        <span className="made-in">MADE IN {translations.en.made_in}</span>
      </div>

      <div className="main-info">
        <h4>
          Model: <span>{model}</span> <FaStar className="star-icon" />
        </h4>
        <p className="product-name">{translations.en.description}</p>

        <div className="barcodes">
          <p>Barcode Color: {barcode_color}</p>
          <p>Barcode Carton: {barcode_carton}</p>
        </div>

        {/* <div className="action-buttons">
          <button className="bulk-order" onClick={handleBulkOrder}>Bulk Order</button>
        </div> */}

        <ProductAccardion
          features={translations.en.features}
          description={translations.en.description}
          specification={product.specifications}
          activeAccordion={activeAccordion}
          toggleAccordion={toggleAccordion}
        />
      </div>
    </div>
  );
}
