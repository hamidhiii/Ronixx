import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import { fetchCategories } from "../../store/categorySlice";
import "./Drum.scss";
import product1 from "../../assets/img/Product1.svg";

const Drum = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const { items: categories, status } = useSelector((state) => state.categories);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    if (status === 'idle') dispatch(fetchCategories());
  }, [status, dispatch]);

  const total = categories.length;
  const radius = 200;
  const deltaAngle = 360 / (total || 1);

  const mod = (n, m) => ((n % m) + m) % m;
  const handleUp = () => setActiveIndex((prev) => mod(prev - 1, total));
  const handleDown = () => setActiveIndex((prev) => mod(prev + 1, total));

  if (status === 'loading') return <p>Загрузка категорий...</p>;
  if (status === 'failed') return <p>Ошибка загрузки категорий</p>;

  return (
    <div className="background">
      <div className="slider-container">
        <div className="circle-slider">
          {categories.map((cat, index) => {
            const angle = (index - activeIndex) * deltaAngle;
            const x = radius * Math.cos((angle * Math.PI) / 180);
            const y = radius * Math.sin((angle * Math.PI) / 180);
            const isActive = index === activeIndex;

            return (
              <Link
                key={cat.id}
                to={`/${cat.slug || cat.nameEn?.toLowerCase()?.replaceAll(' ', '-')}`}
                className={`slider-item ${isActive ? "active" : ""}`}
                style={{
                  transform: `translate(${x}px, ${y}px)`,
                  zIndex: total - Math.abs(index - activeIndex),
                }}
              >
                <img src={product1} alt={cat.nameEn} />
              </Link>
            );
          })}
        </div>
        {categories[activeIndex] && (
          <div className="slider-text fade-in">
            {t(categories[activeIndex].nameEn)}
          </div>
        )}
      </div>

      <div className="controls">
        <button className="prev-btn" onClick={handleUp}>▲</button>
        <button className="next-btn" onClick={handleDown}>▼</button>
      </div>
    </div>
  );
};

export default Drum;
