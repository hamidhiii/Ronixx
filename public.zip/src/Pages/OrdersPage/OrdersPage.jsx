import React from "react";

export default function OrdersPage() {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>🧾 Мои заказы</h2>
      <p>Здесь будут отображаться ваши заказы.</p>
    </div>
  );
}
