import React from "react";

const MyOrdersPage = () => {
  return (
    <div className="profile-content">
      <h1>📦 My Orders</h1>
      <p>Here will be the list of your orders...</p>
    </div>
  );
};

export default MyOrdersPage;
