import React from 'react'
import DrilsHeader from '../../components/DrilsHeader/DrilsHeader'
import SubCategoryMeansuring from '../../components/SubCategoryMeansuring/SubCategoryMeansuring'

export default function SubCategoryMeasuring() {
  return (
    <div>
        <DrilsHeader/>
        <SubCategoryMeansuring/>
    </div>
  )
}
