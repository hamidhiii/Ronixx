import React from 'react'
import DrilsHeader from '../../components/DrilsHeader/DrilsHeader'
import SubcategoryStorage from '../../components/SubcategoryStorage/SubcategoryStorage'

export default function SubCAtegoryStorage() {
  return (
    <div>
        <DrilsHeader/>
        <SubcategoryStorage/>
    </div>
  )
}
