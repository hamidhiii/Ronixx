import React from 'react'
import DrilsHeader from '../../components/DrilsHeader/DrilsHeader'
import SubCategorySuplier from '../../components/SubCategorySuplier/SubCategorySuplier'

export default function SubCategorySuplierr() {
  return (
    <div>
        <DrilsHeader/>
        <SubCategorySuplier/>
    </div>
  )
}
