import React from 'react'
import { Container, Row, Col } from 'react-bootstrap'
import ronix from '../../assets/img/Variant.png'
import './Footer.scss'
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'

export default function Footer() {
  const { t } = useTranslation();

  return (
    <div className='footer'>
      <Container>
        <Row className='align-items-start'>
          <Col xs={12} md={3} className='footer-logo'>
            <img src={ronix} alt="Ronix" className='logo' />
          </Col>

          <Col xs={12} md={3} className='footer-column'>
            <div className='footer-title'>{t('all_products')}</div>
            <ul>
              <li><Link to='/'>{t('electro_tools')}</Link></li>
              <li><Link to='/'>{t('hand_tools_wholesale')}</Link></li>
              <li><Link to='/'>{t('flashlights_wholesale')}</Link></li>
            </ul>
          </Col>

          <Col xs={12} md={3} className='footer-column'>
            <ul>
              <li><Link to='/'>{t('protection_tools')}</Link></li>
              <li><Link to='/'>{t('accessories_for_tools')}</Link></li>
              <li><Link to='/'>{t('toolboxes_bags')}</Link></li>
            </ul>
          </Col>

          <Col xs={12} md={3} className='footer-column'>
            <ul>
              <li><Link to='/'>{t('lifting_equipment')}</Link></li>
              <li><Link to='/'>{t('jacks')}</Link></li>
              <li><Link to='/'>{t('measuring_devices')}</Link></li>
            </ul>
          </Col>
        </Row>
      </Container>
    </div>
  );
}
