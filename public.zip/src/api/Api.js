import axios from 'axios';

const api = axios.create({
  baseURL: 'http://139.59.62.159/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

export const getProducts = () => api.get('/Product/GetAll');
export const getCategories = () => api.get('/Category/GetAll');

export default api;
