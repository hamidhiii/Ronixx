import categoryReducer from './categorySlice';

export const store = configureStore({
  reducer: {
    cart: cartReducer,
    search: searchReducer,
    products: productReducer,
    categories: categoryReducer, 
  },
});
