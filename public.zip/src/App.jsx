import React, { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import { useLocation, useNavigate } from "react-router-dom";
import { Routes, Route } from "react-router-dom";
import { useDispatch } from "react-redux";

import Home from "./Pages/Home/Home";
import SubCategoryElectro from "./Pages/SubCategoryElectro/SubCategoryElectro";
import SubCategoryHand from "./Pages/SubCategoryHand/SubCategoryHand";
import SubCategoryFlashLights from "./Pages/SubCategoryFlashLights/SubCategoryFlashLights";
import SubCategoryMeasuring from "./Pages/SubCategoryMeasuring/SubCategoryMeasuring";
import SubCategoryProtection from "./Pages/SubCategoryProtection/SubCategoryProtection";
import SubCategoryAccessories from "./Pages/SubCategoryAccessories/SubCategoryAccessories";
import SubCAtegoryStorage from "./Pages/SubCAtegoryStorage/SubCAtegoryStorage";
import SubCategorySuplierr from "./Pages/SubCategorySuplier/SubCategorySuplierr";
import SubCategoryJacks from "./Pages/SubCategoryJacks/SubCategoryJacks";
import SubProductDrel from "./Pages/SubProductDrel/SubProductDrel";
import ProductDetail from "./components/ProductDetail/ProductDetail";
import Basket from "./Pages/Basket/Basket";
import ContactUs from "./Pages/ContactUs/ContactUs";
import SearchResults from "./Pages/SearchResults/SearchResults";

import LoginPage from "./Pages/LoginPage/LoginPage";
import RegisterPage from "./Pages/RegisterPage/RegisterPage";
import ForgotPasswordPage from "./Pages/ForgotPasswordPage/ForgotPasswordPage";
import ProfilePage from "./Pages/ProfilePage/ProfilePage";

import Navbar from "./components/Navbar/Navbar";
import Footer from "./components/Footer/Footer";
import { fetchProducts } from "./redux/productSlice";

export default function App() {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch(); 

  const isAuthPage = ["/login", "/register", "/forgot-password"].includes(
    location.pathname
  );

  const handleSearch = (text) => {
    navigate(`/search?q=${encodeURIComponent(text)}`);
  };

  useEffect(() => {
    dispatch(fetchProducts());  
  }, [dispatch]);

  return (
    <div>
      {!isAuthPage && <Navbar onSearch={handleSearch} />}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/electro-tools" element={<SubCategoryElectro />} />
        <Route path="/hand-tools" element={<SubCategoryHand />} />
        <Route path="/flashlights" element={<SubCategoryFlashLights />} />
        <Route path="/measuring-devices" element={<SubCategoryMeasuring />} />
        <Route path="/protection" element={<SubCategoryProtection />} />
        <Route path="/accessories" element={<SubCategoryAccessories />} />
        <Route path="/toolboxes" element={<SubCAtegoryStorage />} />
        <Route path="/lifting-equipment" element={<SubCategorySuplierr />} />
        <Route path="/jacks" element={<SubCategoryJacks />} />
        <Route path="/products" element={<SubProductDrel />} />
        <Route path="/product-details" element={<ProductDetail />} />
        <Route path="/basket" element={<Basket />} />
        <Route path="/contact-Us-&-locations" element={<ContactUs />} />
        <Route path="/search" element={<SearchResults />} />

        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/profile" element={<ProfilePage />} />
      </Routes>
      {!isAuthPage && <Footer />}
    </div>
  );
}
