import React from 'react'

export default function Location() {
  return (
    <div>
        <h1>dfdfderf</h1>

    </div>
  )
}
